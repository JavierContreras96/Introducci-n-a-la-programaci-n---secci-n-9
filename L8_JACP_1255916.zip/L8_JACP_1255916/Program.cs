﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Laboratorio 8");
static void Main(string[] args, ConsoleKeyInfo consoleKeyInfo)
{
    int salir = 0;
    while (salir != 1)
    {
        Console.WriteLine("Menú");
        Console.WriteLine("a) Sumatoria");
        Console.WriteLine("b) Mostrar tablas de multiplicar");
        Console.WriteLine("c) Número Perfecto");
        Console.WriteLine("d) Salir");
        Console.WriteLine("Ingrese la letra de la opción a elegir: ");
        string menu = Console.ReadLine();
        switch (menu)
        {
            case "a":
                int inicio = 1;
                int final = 0;
                int ecuacion = 0;
                Console.WriteLine("SUMATORIA");
                Console.WriteLine("Ingrese el número a utilizar: ");
                final = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("operación");

                do
                {
                    ecuacion = inicio + ecuacion;
                    Console.Write(inicio);
                    if (inicio < final)
                    {
                        Console.Write(" + ");
                    }
                    inicio++;
                } while (inicio <= final);
                Console.WriteLine("\nEl resultado es: " + ecuacion);
                break;
            case "b":
                int numero = 0;
                int resultado = 0;
                Console.WriteLine("TABLA DE MULTIPLICAR");
                Console.WriteLine("Ingrese número para mostrar la tabla ");
                numero = Convert.ToInt32(Console.ReadLine());
                for (int i = 1; i <= 10; i++)
                {
                    resultado = numero * i;
                    Console.WriteLine(numero + " x " + i + " = " + resultado);
                }
                break;
            case "c":
                int dato;
                int salida = 0;
                int perfecto = 0;
                Console.WriteLine("NÚMERO PERFECTO");
                while (salida != 1)
                {
                    Console.WriteLine("Ingrese número para usar ");
                    dato = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Operación");
                    if (dato <= 0)
                    {
                        Console.WriteLine("Ingreso de dato erroneo");
                    }
                    else if (dato == 1)
                    {
                        Console.WriteLine(dato);
                        perfecto = 1;
                    }
                    {
                        for (int i = 1; i < dato; i++)
                        {
                            int resul;
                            resul = dato % i;

                            if (resul == 0)
                            {

                                perfecto = perfecto + i;
                                Console.Write(i);
                                if (dato > 1)
                                {
                                    Console.Write(" + ");
                                }
                            }
                        }
                        Console.WriteLine("\n" + "La suma de sus divisores es: " + perfecto);
                        if (perfecto == dato)
                        {
                            Console.WriteLine("El número es perfecto");
                        }
                        else
                        {
                            Console.WriteLine("El número no es perfecto");
                        }
                        salida = 1;
                    }
                }

                break;
            case "d":
                Console.WriteLine("Gracias por usar el programa");
                salir = 1;
                break;
            default:
                Console.WriteLine("Ingreso de dato erroneo");
                break;
        }
    }

    consoleKeyInfo;